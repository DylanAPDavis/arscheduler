package net.floodlightcontroller.arscheduler;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.projectfloodlight.openflow.protocol.OFFactories;
import org.projectfloodlight.openflow.protocol.OFFactory;
import org.projectfloodlight.openflow.protocol.OFFlowAdd;
import org.projectfloodlight.openflow.protocol.OFFlowRemoved;
import org.projectfloodlight.openflow.protocol.OFMessage;
import org.projectfloodlight.openflow.protocol.OFPacketIn;
import org.projectfloodlight.openflow.protocol.OFPacketQueue;
import org.projectfloodlight.openflow.protocol.OFPortDesc;
import org.projectfloodlight.openflow.protocol.OFQueueGetConfigReply;
import org.projectfloodlight.openflow.protocol.OFQueueGetConfigRequest;
import org.projectfloodlight.openflow.protocol.OFQueueStatsEntry;
import org.projectfloodlight.openflow.protocol.OFType;
import org.projectfloodlight.openflow.protocol.OFVersion;
import org.projectfloodlight.openflow.protocol.action.OFAction;
import org.projectfloodlight.openflow.protocol.action.OFActionEnqueue;
import org.projectfloodlight.openflow.protocol.action.OFActionOutput;
import org.projectfloodlight.openflow.protocol.action.OFActionSetQueue;
import org.projectfloodlight.openflow.protocol.action.OFActions;
import org.projectfloodlight.openflow.protocol.instruction.OFInstruction;
import org.projectfloodlight.openflow.protocol.instruction.OFInstructionApplyActions;
import org.projectfloodlight.openflow.protocol.instruction.OFInstructions;
import org.projectfloodlight.openflow.protocol.match.Match;
import org.projectfloodlight.openflow.protocol.match.MatchField;
import org.projectfloodlight.openflow.protocol.queueprop.OFQueueProp;
import org.projectfloodlight.openflow.protocol.queueprop.OFQueuePropMaxRate;
import org.projectfloodlight.openflow.protocol.queueprop.OFQueuePropMinRate;
import org.projectfloodlight.openflow.protocol.ver13.OFQueuePropertiesSerializerVer13;
import org.projectfloodlight.openflow.types.DatapathId;
import org.projectfloodlight.openflow.types.EthType;
import org.projectfloodlight.openflow.types.IPv4Address;
import org.projectfloodlight.openflow.types.IPv6Address;
import org.projectfloodlight.openflow.types.IpProtocol;
import org.projectfloodlight.openflow.types.MacAddress;
import org.projectfloodlight.openflow.types.OFPort;
import org.projectfloodlight.openflow.types.TransportPort;
import org.projectfloodlight.openflow.types.VlanVid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.util.concurrent.ListenableFuture;
import com.sun.corba.se.impl.orbutil.threadpool.TimeoutException;

import net.floodlightcontroller.core.FloodlightContext;
import net.floodlightcontroller.core.IControllerCompletionListener;
import net.floodlightcontroller.core.IFloodlightProviderService;
import net.floodlightcontroller.core.IOFMessageListener;
import net.floodlightcontroller.core.IOFSwitch;
import net.floodlightcontroller.core.IOFSwitchListener;
import net.floodlightcontroller.core.PortChangeType;
import net.floodlightcontroller.core.IListener.Command;
import net.floodlightcontroller.core.internal.IOFSwitchService;
import net.floodlightcontroller.core.module.FloodlightModuleContext;
import net.floodlightcontroller.core.module.FloodlightModuleException;
import net.floodlightcontroller.core.module.IFloodlightModule;
import net.floodlightcontroller.core.module.IFloodlightService;
import net.floodlightcontroller.devicemanager.IDevice;
import net.floodlightcontroller.devicemanager.IDeviceListener;
import net.floodlightcontroller.devicemanager.IDeviceService;
import net.floodlightcontroller.devicemanager.IEntityClass;
import net.floodlightcontroller.devicemanager.SwitchPort;
import net.floodlightcontroller.forwarding.Forwarding;
import net.floodlightcontroller.linkdiscovery.ILinkDiscoveryService;
import net.floodlightcontroller.packet.ARP;
import net.floodlightcontroller.packet.Ethernet;
import net.floodlightcontroller.packet.IPv4;
import net.floodlightcontroller.packet.TCP;
import net.floodlightcontroller.packet.UDP;
import net.floodlightcontroller.restserver.IRestApiService;
import net.floodlightcontroller.routing.Link;
import net.floodlightcontroller.topology.ITopologyService;




/**********************************************************
 * ARSCHEDULER MODIFICATION!!!!!!!!!!!
 * ADDED IF STATEMENT: FORWARDING MODULE ONLY HANDLES ARP
 * PACKETS NOW. REMOVE THIS IF STATEMENT IF NOT USING
 * ARSCHEDULER.
 * LOOK IN net.floodlightcontroller.forwarding.Forwading
 * Function: processPacketInMessage
 **********************************************************/
/**
 * Defines an interface for loadable Floodlight modules.
 *
 * At a high level, these functions are called in the following order:
 * <ol>
 * <li> getServices() : what services does this module provide
 * <li> getDependencies() : list the dependencies
 * <li> init() : internal initializations (don't touch other modules)
 * <li> startUp() : external initializations (<em>do</em> touch other modules)
 * </ol>
 *
 */
public class ARScheduler implements IFloodlightModule, IARSchedulerService, IOFMessageListener {
	protected IFloodlightProviderService floodlightProvider;
	protected ITopologyService topologyService;
	protected IDeviceService deviceManagerService;
	protected IOFSwitchService switchService;
	protected IRestApiService restApiService;
	protected static Logger logger;
	protected OFFactory of13Factory;
	
	protected ArrayList<IDevice> devices;
	protected ArrayList<Link> links;
	protected Map<DatapathId, IOFSwitch> switchMap;
	protected HashMap<IOFSwitch, ArrayList<OFPortDesc>> switchPortMap;
	protected HashMap<IOFSwitch, HashMap<Integer, ArrayList<FlowQueue>>> switchQueueMap;
	
	
	protected ResourceManager theRM;
	protected FlowScheduler scheduler;
	protected FloodlightTopologyBuilder floodlightTopoBuilder;
	protected FlowProvisioner flowProvisioner;
	protected TopologyBuilder topoBuilder;
	
	static protected long bitsPerGb = 1000000000;
	protected HashMap<Long, Long> queueBandwidthMap;

	
	 /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	 * 
	 *   Reservation Handlers
	 * 
	 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	 */
	@Override
	public String handleNewFlow(Flow flow)
	{
		long flowID = flow.getID();
		flow = scheduler.scheduleNewFlow(flow);
		
		if(flow == null)
			return "Flow " + flowID + " reservation FAILED";
		else
		{
			int startHour = (int)(flow.getStartTime() / 60 / 60);
			int startMinute = (int)(flow.getStartTime() / 60 % 60);
			int startSecond = 0;	
			
			// Create and start Thread to delay scheduling in the flowProvisioner. The call commented out below is now done in ScheduleThread class.
			SchedulingThread schedulingThread = new SchedulingThread(this, flow, startHour, startMinute, startSecond);
			/*this.flowProvisioner.provisionFlowPath(this.theRM.getFlowFromRM(flow), this.switchMap, this.switchQueueMap); */
			
			return "Flow " + flow.getID() + " reservation SUCCESS";
		}
	}
	
	public String releaseExpiredFlow(Flow flow)
	{
		boolean success = scheduler.releaseFinishedFlow(flow);
				
		if(success == false)
			return "Flow " + flow.getID() + " release FAILED";
		else
			return "Flow " + flow.getID() + " release SUCCESS";
	}
	
	/**
	 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	 * 
	 *   Initialize State
	 * 
	 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	 */
	@Override 
	public ArrayList<Node> initializeState(){
		this.floodlightTopoBuilder.updateTopologyInformation(devices, links, switchMap, switchPortMap, switchQueueMap, queueBandwidthMap);
		
		this.devices = floodlightTopoBuilder.getDevices();
		
		this.links = floodlightTopoBuilder.getLinks();
		
		this.switchMap = floodlightTopoBuilder.getSwitchMap();
		
		this.switchPortMap = floodlightTopoBuilder.getSwitchPortMap();
		 
		this.switchQueueMap = floodlightTopoBuilder.getSwitchQueueMap();
		
		Topology newTopology = topoBuilder.convertTopology(devices, links, switchMap, switchPortMap);
		this.theRM.intializeState(newTopology);
		return this.getTopology().getNodes();
	}
	
	public Topology getTopology(){
		return theRM.getTopology();
	}
	
	
	public void generateQueueBandwidthMap(){
		/*
		queue_bandwidth_dict = {1: 1*bpGb, 2: 1*bpGb, 3: 1*bpGb, 4: 1*bpGb, 5: 1*bpGb,
	            6: 1*bpGb, 7: 1*bpGb, 8: 1*bpGb, 9: 1*bpGb, 10: 1*bpGb,
	            11: 2*bpGb, 12: 2*bpGb, 13: 2*bpGb, 14: 2*bpGb, 15: 2*bpGb,
	            16: 3*bpGb, 17: 3*bpGb, 18: 3*bpGb,
	            19: 4*bpGb, 20: 4*bpGb,
	            21: 5*bpGb, 22: 5*bpGb,
	            23: 6*bpGb,
	            24: 7*bpGb,
	            25: 8*bpGb,
	            26: 9*bpGb,
	            27: 10*bpGb}
		*/
		this.queueBandwidthMap = new HashMap<Long, Long>();
		for(long queueNum = 1; queueNum < 28; queueNum++){
			long bandwidth = ARScheduler.bitsPerGb;
			if(queueNum < 11)
				bandwidth *=  1;
			else if(queueNum < 16)
				bandwidth *= 2;
			else if(queueNum < 19)
				bandwidth *= 3;
			else if(queueNum < 21)
				bandwidth *= 4;
			else if(queueNum < 23)
				bandwidth *= 5;
			else if(queueNum == 23)
				bandwidth *= 6;
			else if(queueNum == 24)
				bandwidth *= 7;
			else if(queueNum == 25)
				bandwidth *= 8;
			else if(queueNum == 26)
				bandwidth *= 9;
			else if(queueNum == 27)
				bandwidth *= 10;
			this.queueBandwidthMap.put(new Long(queueNum), new Long(bandwidth));
		}
	}
	
	//@Override
	public String getName() {
	    return ARScheduler.class.getSimpleName();
	}
	
    /**
     * Return the list of interfaces that this module implements.
     * All interfaces must inherit IFloodlightService
     * @return
     */
	@Override
	public Collection<Class<? extends IFloodlightService>> getModuleServices() {
		Collection<Class<? extends IFloodlightService>> our_services = new ArrayList<Class<? extends IFloodlightService>>();
		our_services.add(IARSchedulerService.class);
		return our_services;
	}

	/**
     * Instantiate (as needed) and return objects that implement each
     * of the services exported by this module.  The map returned maps
     * the implemented service to the object.  The object could be the
     * same object or different objects for different exported services.
     * @return The map from service interface class to service implementation
     */
	@Override
	public Map<Class<? extends IFloodlightService>, IFloodlightService> getServiceImpls() {
		Map<Class<? extends IFloodlightService>, IFloodlightService> our_service_map = new HashMap<Class<? extends IFloodlightService>, IFloodlightService>();
		our_service_map.put(IARSchedulerService.class, this);
		return our_service_map;
	}

    /**
     * Get a list of Modules that this module depends on.  The module system
     * will ensure that each these dependencies is resolved before the
     * subsequent calls to init().
     * @return The Collection of IFloodlightServices that this module depnds
     *         on.
     */
	@Override
	public Collection<Class<? extends IFloodlightService>> getModuleDependencies() {
		Collection<Class<? extends IFloodlightService>> services = new ArrayList<Class<? extends IFloodlightService>>();
		services.add(IFloodlightProviderService.class);
		services.add(ITopologyService.class);
		services.add(IDeviceService.class);
		services.add(IRestApiService.class);
		services.add(ILinkDiscoveryService.class);
		return services;
	}

    /**
     * This is a hook for each module to do its <em>internal</em> initialization,
     * e.g., call setService(context.getService("Service"))
     *
     * All module dependencies are resolved when this is called, but not every module
     * is initialized.
     *
     * @param context
     * @throws FloodlightModuleException
     */
	@Override
	public void init(FloodlightModuleContext context) throws FloodlightModuleException {
		this.floodlightProvider = context.getServiceImpl(IFloodlightProviderService.class);
		this.deviceManagerService = context.getServiceImpl(IDeviceService.class);
		this.topologyService = context.getServiceImpl(ITopologyService.class);
		this.switchService = context.getServiceImpl(IOFSwitchService.class);
		this.restApiService = context.getServiceImpl(IRestApiService.class);
		logger = LoggerFactory.getLogger(ARScheduler.class);

		this.of13Factory =  OFFactories.getFactory(OFVersion.OF_13);
		
		this.theRM = new ResourceManager();
		this.scheduler = new FlowScheduler(theRM);
		this.floodlightTopoBuilder = new FloodlightTopologyBuilder(this);
		this.flowProvisioner = new FlowProvisioner(this.of13Factory);
		this.topoBuilder = new TopologyBuilder();
		
		this.generateQueueBandwidthMap();
        //this.devices = (Collection<IDevice>) deviceManagerService.getAllDevices();
	}

    /**
     * This is a hook for each module to do its <em>external</em> initializations,
     * e.g., register for callbacks or query for state in other modules
     *
     * It is expected that this function will not block and that modules that want
     * non-event driven CPU will spawn their own threads.
     *
     * @param context
     */
	@Override
	public void startUp(FloodlightModuleContext context) throws FloodlightModuleException {
		logger.info("Starting {}", this.getName());
		restApiService.addRestletRoutable(new ARSchedulerWebRoutable());
	    floodlightProvider.addOFMessageListener(OFType.FLOW_REMOVED, this);
	    //switchService.addOFSwitchListener(this);
	}

	
	@Override
	public boolean isCallbackOrderingPrereq(OFType type, String name) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isCallbackOrderingPostreq(OFType type, String name) {
		// TODO Auto-generated method stub
        return (type.equals(OFType.PACKET_IN) && name.equals("forwarding"));
	}

	@Override
	public net.floodlightcontroller.core.IListener.Command receive(
			IOFSwitch sw, OFMessage msg, FloodlightContext cntx) {
		logger.info(msg.toString());
		logger.info(sw.toString());
		
		OFMessageParser parser = new OFMessageParser();
		parser.parseMessage(msg.toString());
		Flow flowToRelease = theRM.getFlowTable().matchFlow(parser.flowID);
		assert(flowToRelease != null);
		releaseExpiredFlow(flowToRelease);
		this.flowProvisioner.releaseQueuesOnSwitch(sw, this.switchQueueMap, flowToRelease);
		return Command.CONTINUE;
	}
	
	/**
	@Override
	public void deviceAdded(IDevice device) {
		// TODO Auto-generated method stub
		logger.info("Device Added: {}", device.toString());
	}

	@Override
	public void deviceMoved(IDevice device) {
		// TODO Auto-generated method stub
		logger.info("Device Moved: {}", device.toString());
	}
	**/
	
}
