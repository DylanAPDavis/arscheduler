package net.floodlightcontroller.arscheduler;

import org.restlet.Context;
import org.restlet.Restlet;
import org.restlet.routing.Router;

import net.floodlightcontroller.restserver.RestletRoutable;

public class ARSchedulerWebRoutable implements RestletRoutable {

	@Override
	public Restlet getRestlet(Context context) {
		Router router = new Router(context);
		router.attach("/state/json", ARSchedulerResource.class);
		router.attach("/schedule/json", ARSchedulerResource.class);
		//router.attach("/topo/json", FlowSchedulerResource.class);
		return router;
	}

	@Override
	public String basePath() {
		return "/wm/flowscheduler";
	}

}
