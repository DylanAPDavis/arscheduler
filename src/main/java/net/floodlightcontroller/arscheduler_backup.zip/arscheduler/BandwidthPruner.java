package net.floodlightcontroller.arscheduler;

import java.util.ArrayList;

/** Prunes out all links which do not meet a Flow's Bandwidth requirements **/
public class BandwidthPruner 
{
	Topology netTopology;
	
	public BandwidthPruner(Topology topo)
	{
		netTopology = topo;
	}
	
	public Topology pruneTopology(long bandwidth)	//bps
	{
		Topology prunedTopo;
		ArrayList<FlowLink> prunedLinks = new ArrayList<FlowLink>();
		
		for(FlowLink l : netTopology.getLinks())
		{
			if(l.getBandwidthAvailabile() >= bandwidth)
				prunedLinks.add(l);
		}
		
		prunedTopo = new Topology(netTopology.getNodes(), prunedLinks);
		
		return prunedTopo;
	}

}

