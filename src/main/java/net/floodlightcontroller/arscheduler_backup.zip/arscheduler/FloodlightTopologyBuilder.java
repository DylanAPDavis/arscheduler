package net.floodlightcontroller.arscheduler;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.TimeUnit;

import net.floodlightcontroller.core.IOFSwitch;
import net.floodlightcontroller.core.internal.IOFSwitchService;
import net.floodlightcontroller.devicemanager.IDevice;
import net.floodlightcontroller.devicemanager.IDeviceService;
import net.floodlightcontroller.devicemanager.SwitchPort;
import net.floodlightcontroller.routing.Link;
import net.floodlightcontroller.topology.ITopologyService;

import org.projectfloodlight.openflow.protocol.OFFactory;
import org.projectfloodlight.openflow.protocol.OFPacketQueue;
import org.projectfloodlight.openflow.protocol.OFPortDesc;
import org.projectfloodlight.openflow.protocol.OFQueueGetConfigReply;
import org.projectfloodlight.openflow.protocol.OFQueueGetConfigRequest;
import org.projectfloodlight.openflow.protocol.OFQueueStatsEntry;
import org.projectfloodlight.openflow.protocol.OFQueueStatsReply;
import org.projectfloodlight.openflow.protocol.OFQueueStatsRequest;
import org.projectfloodlight.openflow.protocol.queueprop.OFQueueProp;
import org.projectfloodlight.openflow.protocol.queueprop.OFQueuePropMaxRate;
import org.projectfloodlight.openflow.protocol.queueprop.OFQueuePropMinRate;
import org.projectfloodlight.openflow.protocol.ver13.OFQueuePropertiesSerializerVer13;
import org.projectfloodlight.openflow.types.DatapathId;
import org.projectfloodlight.openflow.types.OFPort;

import com.google.common.util.concurrent.ListenableFuture;

public class FloodlightTopologyBuilder {
	
	protected ArrayList<IDevice> devices;
	protected ArrayList<Link> links;
	protected Map<DatapathId, IOFSwitch> switchMap;
	protected HashMap<IOFSwitch, ArrayList<OFPortDesc>> switchPortMap;
	protected HashMap<IOFSwitch, HashMap<Integer, ArrayList<FlowQueue>>> switchQueueMap;
	protected ARScheduler arscheduler;
	
	public FloodlightTopologyBuilder(ARScheduler arscheduler){
		this.arscheduler = arscheduler;
	}
	
	
	public void updateTopologyInformation(ArrayList<IDevice> devices, ArrayList<Link>  links, Map<DatapathId, IOFSwitch>  switchMap, 
			HashMap<IOFSwitch, ArrayList<OFPortDesc>> switchPortMap, HashMap<IOFSwitch, HashMap<Integer, ArrayList<FlowQueue>>>  switchQueueMap,
			HashMap<Long, Long> queueBandwidthMap){
		this.devices = null;
		this.links = null;
		this.switchMap = null;
		this.switchPortMap = null;
		this.switchQueueMap = null;
		this.devices = getDevices();
		this.links = getLinks();
		this.switchMap = getSwitchMap();
		this.switchPortMap = getPortMap();
		this.switchQueueMap = getQueueMap(queueBandwidthMap);
	}
	
	public ArrayList<IDevice> getDevices(){
		ArrayList<IDevice> updatedDevices = new ArrayList<IDevice>();
		Collection<? extends IDevice> deviceList = arscheduler.deviceManagerService.getAllDevices();
		for (IDevice device : deviceList){
			SwitchPort[] attachmentPoints = device.getAttachmentPoints();
			for (SwitchPort ap : attachmentPoints){
				if(ap.getPort().getPortNumber() > 0){
					updatedDevices.add(device);
				}
			}
		}
		return updatedDevices;
	}
	
	public ArrayList<Link> getLinks(){
		Map<DatapathId, Set<Link>> linkMap = arscheduler.topologyService.getAllLinks();
		ArrayList<Link> updatedLinks = new ArrayList<Link>();
		for(Set<Link> linkSet : linkMap.values()){
			for(Link l : linkSet){
				if(!updatedLinks.contains(l)){
					updatedLinks.add(l);
				}
			}
		}
		return updatedLinks;
	}
	
	public Map<DatapathId, IOFSwitch> getSwitchMap(){
		return arscheduler.switchService.getAllSwitchMap();
	}
	
	public HashMap<IOFSwitch, ArrayList<OFPortDesc>> getPortMap(){
		HashMap<IOFSwitch, ArrayList<OFPortDesc>> switchPortMap = new HashMap<IOFSwitch, ArrayList<OFPortDesc>>();
		for(DatapathId id : this.switchMap.keySet()){
			IOFSwitch switchObject = this.switchMap.get(id);
			Collection<OFPortDesc> ports = switchObject.getPorts();
			ArrayList<OFPortDesc> usablePorts = new ArrayList<OFPortDesc>();
			for(OFPortDesc port : ports){
				//Integer portNum = port.getPortNo().getPortNumber();
				//Long portBandwidth = port.getCurrSpeed();
				if(port.getCurrSpeed() > 0){
					//getCurrSpeed returns bandwidth in Megabits
					usablePorts.add(port);
				}
			}
			switchPortMap.put(switchObject, usablePorts);
		}
		return switchPortMap;
	}
	
	public HashMap<IOFSwitch, HashMap<Integer, ArrayList<FlowQueue>>> getQueueMap(HashMap<Long, Long> queueBandwidthMap){
		
		HashMap<IOFSwitch, HashMap<Integer, ArrayList<FlowQueue>>> queueMap = new HashMap<IOFSwitch, HashMap<Integer, ArrayList<FlowQueue>>>();		
		
		for(IOFSwitch thisSwitch : this.switchMap.values()){
			
			HashMap<Integer, ArrayList<FlowQueue>> portQueueMap = new HashMap<Integer, ArrayList<FlowQueue>>();
			for(OFPortDesc portDesc : this.switchPortMap.get(thisSwitch)){
				ArrayList<FlowQueue> queuesThisPort = new ArrayList<FlowQueue>();
				OFQueueGetConfigRequest cr = arscheduler.of13Factory.buildQueueGetConfigRequest().setPort(portDesc.getPortNo()).build(); // Get all queues on all ports 
				
				ListenableFuture<OFQueueGetConfigReply> future = thisSwitch.writeRequest(cr); // Send request to switch 1
				try { 
				    // Wait up to 10s for a reply; return when received; else exception thrown 
				    OFQueueGetConfigReply reply = future.get(10, TimeUnit.SECONDS);
				    // Iterate over all queues 
				    for (OFPacketQueue q : reply.getQueues()) {
				    	///queues.add(q);
				    	if(q.getQueueId() == 0)
				    		continue;
				    	FlowQueue newQueue = new FlowQueue(portDesc.getPortNo().getPortNumber(), q.getQueueId(), 
				    			queueBandwidthMap.get(Long.valueOf(q.getQueueId())));
				    	queuesThisPort.add(newQueue);
				    }
				    int portNum = portDesc.getPortNo().getPortNumber();
				    portQueueMap.put(Integer.valueOf(portNum), queuesThisPort);
				} catch (InterruptedException | ExecutionException | TimeoutException e) { 
				    e.printStackTrace();
				}
			}
			queueMap.put(thisSwitch, portQueueMap);	
	    	
		}
		
		return queueMap;
	}


	public HashMap<IOFSwitch, ArrayList<OFPortDesc>> getSwitchPortMap() {
		return switchPortMap;
	}


	public void setSwitchPortMap(
			HashMap<IOFSwitch, ArrayList<OFPortDesc>> switchPortMap) {
		this.switchPortMap = switchPortMap;
	}


	public HashMap<IOFSwitch, HashMap<Integer, ArrayList<FlowQueue>>>  getSwitchQueueMap() {
		return switchQueueMap;
	}


	public void setSwitchQueueMap(HashMap<IOFSwitch, HashMap<Integer, ArrayList<FlowQueue>>>  switchQueueMap) {
		this.switchQueueMap = switchQueueMap;
	}


	public void setDevices(ArrayList<IDevice> devices) {
		this.devices = devices;
	}


	public void setLinks(ArrayList<Link> links) {
		this.links = links;
	}


	public void setSwitchMap(Map<DatapathId, IOFSwitch> switchMap) {
		this.switchMap = switchMap;
	}
}
