package net.floodlightcontroller.arscheduler;

/** Input comes from REST App **/
public class Flow 
{
	private Node srcNode;
	private Node dstNode;
	private String srcIP;
	private String dstIP;
	private static long classFlowID = 0;
	private long flowID;
	private long bandwidth;  // Mbps
	
	//startTime & endTime - number of seconds since 00:00
	private long startTime;
	private long endTime;
	private boolean successfullyScheduled;
	
	public Flow(Node srcAddr, Node dstAddr, long bw, long start, long end, String srcIP, String dstIP)
	{
		srcNode = srcAddr;
		dstNode = dstAddr;
		flowID = ++classFlowID;
		bandwidth = bw;
		startTime = start;
		endTime = end;
		this.srcIP = srcIP;
		this.dstIP = dstIP;
		
		successfullyScheduled = false;
	}
	
	public void schedulingSuccess(boolean success)
	{
		successfullyScheduled = success;
	}
	
	public boolean getSuccess()
	{
		return successfullyScheduled;
	}
	
	public Node getSource()
	{
		return srcNode;
	}
	
	public Node getDest()
	{
		return dstNode;
	}
	
	public long getID()
	{
		return flowID;
	}
	
	public long getBandwidth()
	{
		return bandwidth;
	}
	
	public String getSrcIP(){
		return srcIP;
	}
	
	public String getDstIP(){
		return dstIP;
	}
	
	public long getStartTime(){
		return startTime;
	}
	
	public long getEndTime(){
		return endTime;
	}
	
	public boolean equals(Flow anotherFlow)
	{
		if(this.flowID == anotherFlow.getID())
		{
			if(this.srcNode.equals(anotherFlow.getSource()))
			{
				if(this.dstNode.equals(anotherFlow.getDest()))
				{
					if(this.bandwidth == anotherFlow.getBandwidth())
					{
						return true;
					}
				}
			}
		}
			
		return false;
	}

	@Override
	public String toString() {
		return "Flow [srcNode=" + srcNode + ", dstNode=" + dstNode
				+ ", flowID=" + flowID + ", bandwidth=" + bandwidth
				+ ", startTime=" + startTime + ", endTime=" + endTime
				+ ", successfullyScheduled=" + successfullyScheduled + "]";
	}
	

}