package net.floodlightcontroller.arscheduler;

public class FlowLink {
	private String linkName;
	private Node srcNode;
	private Node dstNode;
	private Port srcPort;
	private Port dstPort;
	private long bandwidthCapacity;		// bps
	private long availableBandwidth;		//bps
	
	public FlowLink(String lnkName, Node src, Node dst, Port srcP, Port dstP, long bw)
	{
		linkName = lnkName;
		srcNode = src;
		dstNode = dst;
		srcPort = srcP;
		dstPort = dstP;
		bandwidthCapacity = bw;
		availableBandwidth = bw;
	}
	
	public long getBandwidthCapacity()
	{
		return this.bandwidthCapacity;
	}
	
	public long getBandwidthAvailabile()
	{
		return this.availableBandwidth;
	}
	
	public boolean decreaseBandwidthAvailable(long lessBandwidth)
	{
		long remainingBW = availableBandwidth - lessBandwidth;
		
		if(remainingBW >= 0)
		{
			this.availableBandwidth -= lessBandwidth;
			return true;
		}
		
		return false;
	}

	public boolean increaseBandwidthAvailable(long moreBandwidth)
	{
		long remainingBW = availableBandwidth + moreBandwidth;
		
		if(remainingBW <= bandwidthCapacity)
		{
			this.availableBandwidth += moreBandwidth;
			return true;
		}
		
		return false;
	}
	
	public Node getSrcNode()
	{
		return this.srcNode;
	}
	
	public Node getDstNode()
	{
		return this.dstNode;
	}
	
	public Port getSrcPort()
	{
		return this.srcPort;
	}
	
	public Port getDstPort()
	{
		return this.dstPort;
	}
	
	
	@Override
	public String toString()
	{
		return ("Link " + linkName + ": (" + srcNode + ", " + dstNode + "), BW: " + availableBandwidth + " bps");
	}
}
