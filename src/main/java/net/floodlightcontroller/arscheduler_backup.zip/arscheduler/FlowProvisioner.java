package net.floodlightcontroller.arscheduler;

import java.awt.List;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import net.floodlightcontroller.core.FloodlightContext;
import net.floodlightcontroller.core.IOFSwitch;
import net.floodlightcontroller.core.internal.IOFSwitchService;
import net.floodlightcontroller.devicemanager.IDevice;
import net.floodlightcontroller.devicemanager.IDeviceService;
import net.floodlightcontroller.devicemanager.SwitchPort;
import net.floodlightcontroller.packet.Ethernet;
import net.floodlightcontroller.packet.IPv4;
import net.floodlightcontroller.packet.TCP;
import net.floodlightcontroller.topology.ITopologyService;

import org.projectfloodlight.openflow.protocol.OFFactory;
import org.projectfloodlight.openflow.protocol.OFFlowAdd;
import org.projectfloodlight.openflow.protocol.OFFlowModFlags;
import org.projectfloodlight.openflow.protocol.OFMessage;
import org.projectfloodlight.openflow.protocol.OFPacketQueue;
import org.projectfloodlight.openflow.protocol.OFPortDesc;
import org.projectfloodlight.openflow.protocol.OFQueueStatsEntry;
import org.projectfloodlight.openflow.protocol.OFQueueStatsProp;
import org.projectfloodlight.openflow.protocol.OFVersion;
import org.projectfloodlight.openflow.protocol.action.OFAction;
import org.projectfloodlight.openflow.protocol.action.OFActionEnqueue;
import org.projectfloodlight.openflow.protocol.action.OFActionOutput;
import org.projectfloodlight.openflow.protocol.action.OFActionSetQueue;
import org.projectfloodlight.openflow.protocol.action.OFActions;
import org.projectfloodlight.openflow.protocol.instruction.OFInstruction;
import org.projectfloodlight.openflow.protocol.instruction.OFInstructionApplyActions;
import org.projectfloodlight.openflow.protocol.instruction.OFInstructions;
import org.projectfloodlight.openflow.protocol.match.Match;
import org.projectfloodlight.openflow.protocol.match.MatchField;
import org.projectfloodlight.openflow.protocol.queueprop.OFQueueProp;
import org.projectfloodlight.openflow.protocol.queueprop.OFQueuePropMaxRate;
import org.projectfloodlight.openflow.protocol.queueprop.OFQueuePropMinRate;
import org.projectfloodlight.openflow.protocol.ver13.OFQueuePropertiesSerializerVer13;
import org.projectfloodlight.openflow.types.DatapathId;
import org.projectfloodlight.openflow.types.EthType;
import org.projectfloodlight.openflow.types.IPv4Address;
import org.projectfloodlight.openflow.types.IpProtocol;
import org.projectfloodlight.openflow.types.MacAddress;
import org.projectfloodlight.openflow.types.OFPort;
import org.projectfloodlight.openflow.types.U64;

public class FlowProvisioner {
	protected OFFactory of13Factory;
	
	
	public FlowProvisioner(OFFactory factory){
		this.of13Factory = factory;
	}
	
	
	public void provisionFlowPath(FlowRouteTuple flowRouteTuple, Map<DatapathId, IOFSwitch> switchMap, 
			HashMap<IOFSwitch, HashMap<Integer, ArrayList<FlowQueue>>> switchQueueMap){
		//Source Node and Destination Node Information
		Flow flow = flowRouteTuple.getFlow();
		Node srcNode = flow.getSource();
		Node dstNode = flow.getDest();
		
		
		//Path Information
		Topology topology = flowRouteTuple.getShortestPathtopology();
		ArrayList<FlowLink> pathLinks = topology.getLinks();
		
		HashMap<Node, ArrayList<Port>> usedPortsMap = buildUsedPortsMap(new HashMap<Node, ArrayList<Port>>(), pathLinks);

		provisionFlowRules(flow, srcNode, dstNode, usedPortsMap, switchMap, switchQueueMap);
	}
	
	public HashMap<Node, ArrayList<Port>> buildUsedPortsMap(HashMap<Node, ArrayList<Port>> usedPortsMap, ArrayList<FlowLink> pathLinks){
		//Build a map of switches to used ports for constructing flow rules
		for(FlowLink link : pathLinks){
			Node linkSrcNode = link.getSrcNode();
			Port linkSrcPort = link.getSrcPort();
			if(linkSrcNode.nodeIsSwitch()){
				updateUsedPortsMap(usedPortsMap, linkSrcNode, linkSrcPort);
			}
			Node linkDstNode = link.getDstNode();
			Port linkDstPort = link.getDstPort();
			if(linkDstNode.nodeIsSwitch()){
				updateUsedPortsMap(usedPortsMap, linkDstNode, linkDstPort);
			}
		}
		return usedPortsMap;
	}
	
	public void updateUsedPortsMap(HashMap<Node, ArrayList<Port>> usedPortsMap, Node node, Port port){
		if(!usedPortsMap.containsKey(node)){
			ArrayList<Port> usedPorts = new ArrayList<>();
			usedPorts.add(port);
			usedPortsMap.put(node, usedPorts);
		}
		else{
			if(!usedPortsMap.get(node).contains(port)){
				usedPortsMap.get(node).add(port);
			}
		}
	}
	
	public void provisionFlowRules(Flow flow, Node srcNode, Node dstNode, HashMap<Node, ArrayList<Port>> usedPortsMap, 
			Map<DatapathId, IOFSwitch> switchMap, HashMap<IOFSwitch, HashMap<Integer, ArrayList<FlowQueue>>> switchQueueMap){
		
		Set<Node> switches = usedPortsMap.keySet();
		for(Node thisSwitch : switches){
			ArrayList<Port> usedPorts = usedPortsMap.get(thisSwitch);
			String srcIP = flow.getSrcIP();
			String dstIP = flow.getDstIP();
			//Provision bidirectional flows
			provisionFlowRule(srcIP, srcNode, dstIP, dstNode, thisSwitch, usedPorts.get(0), usedPorts.get(1), flow, switchMap, switchQueueMap);
			provisionFlowRule(dstIP, dstNode, srcIP, srcNode, thisSwitch, usedPorts.get(1), usedPorts.get(0), flow, switchMap, switchQueueMap);
		}
	}
	
	public void provisionFlowRule(String srcIPString, Node srcNode, String dstIPString, Node dstNode, Node thisSwitch, Port inPort, 
			Port outPort, Flow flow, Map<DatapathId, IOFSwitch> switchMap, HashMap<IOFSwitch, HashMap<Integer, ArrayList<FlowQueue>>> switchQueueMap){
		

		IOFSwitch thisIOFSwitch = switchMap.get(DatapathId.of(thisSwitch.getNodeName()));
		
		long queueId = getMatchingQueueId(flow, switchQueueMap, thisIOFSwitch, outPort);
		if(queueId == -1){
			ARScheduler.logger.warn("NO QUEUE FOUND TO MATCH FLOW");
			return;
		}
		
		Long timeoutSeconds = getTimeoutSeconds(flow.getStartTime(), flow.getEndTime());
		
		//Create Address Object for Source and Destination
		MacAddress srcMac = MacAddress.of(srcNode.getNodeName());
		IPv4Address srcIP = IPv4Address.of(srcIPString);
		
		MacAddress dstMac = MacAddress.of(dstNode.getNodeName());
		IPv4Address dstIP = IPv4Address.of(dstIPString);
		
		// Create a match for incoming port and src/dst MAC Addresses
		Match ipMatch = of13Factory.buildMatch()
				.setExact(MatchField.IN_PORT, OFPort.of(inPort.getID()))
				.setExact(MatchField.ETH_TYPE, EthType.IPv4)
				.setExact(MatchField.IPV4_SRC, srcIP)
				.setExact(MatchField.IPV4_DST, dstIP)
				.build();

		
		// Create instructions that will be passed to switch for the above match
		OFInstructions instructions = of13Factory.instructions();
		ArrayList<OFAction> actionList = new ArrayList<OFAction>();
		OFActions actions = of13Factory.actions();
		
		//Output Packets on the specified QUEUE
		// For OpenFlow 1.0 
		
		if (of13Factory.getVersion().compareTo(OFVersion.OF_10) == 0) {
		    OFActionEnqueue enqueue = actions.buildEnqueue()
		        .setPort(OFPort.of(outPort.getID())) // Must specify port number 
		        .setQueueId(queueId)
		        .build();
		    actionList.add(enqueue);
		} else { // For OpenFlow 1.1+ 
		    OFActionSetQueue setQueue = actions.buildSetQueue()
		        .setQueueId(queueId)
		        .build();
		    actionList.add(setQueue);
		}
		
		// Output packets on the specified outgoing port
		OFActionOutput output = actions.buildOutput()
				.setPort(OFPort.of(outPort.getID()))
				.setMaxLen(Integer.MAX_VALUE)
				.build();
		actionList.add(output);
		
		
		// Create list of instructions for the flowAdd
		OFInstructionApplyActions applyActions = instructions.buildApplyActions()
				.setActions(actionList)
				.build();
		ArrayList<OFInstruction> instructionList = new ArrayList<OFInstruction>();
		instructionList.add(applyActions);
		
		
		// Create flag so that switch notifies controller when flow removed
		HashSet<OFFlowModFlags> flags = new HashSet<OFFlowModFlags>();
		flags.add(OFFlowModFlags.SEND_FLOW_REM);
		
		// Create the flowAdd
		OFFlowAdd flowAddIP = of13Factory.buildFlowAdd()
				.setMatch(ipMatch)
				.setInstructions(instructionList)
				.setPriority(1)
				.setHardTimeout(timeoutSeconds.intValue())
				.setFlags(flags)
				.setCookie(U64.of(Long.valueOf(flow.getID())))
				.build();
	

		// Write the flowAdd to the switch
		thisIOFSwitch.write(flowAddIP);
		
	}
	

	private Long getTimeoutSeconds(long startTime, long endTime) {
		// TODO Auto-generated method stub
		return new Long(Math.abs(endTime - startTime));
	}

	private long getMatchingQueueId(Flow flow,
			HashMap<IOFSwitch, HashMap<Integer, ArrayList<FlowQueue>>> switchQueueMap,
			IOFSwitch thisSwitch, Port outPort) {
		
		ArrayList<FlowQueue> queues = switchQueueMap.get(thisSwitch).get(outPort.getID());
		for(int queueIndex = 0; queueIndex < queues.size(); queueIndex++){
			FlowQueue queue = queues.get(queueIndex);
			if(queue.getBandwidth() == flow.getBandwidth() && !queue.isUsed()){
				long queueId = queue.getQueueId();
				switchQueueMap.get(thisSwitch).get(outPort.getID()).get(queueIndex).setUsed(true);
				switchQueueMap.get(thisSwitch).get(outPort.getID()).get(queueIndex).setFlowID(flow.getID());
				return queueId;
			}
		}
		return -1;
	}

	public void releaseQueuesOnSwitch(
			IOFSwitch sw,
			HashMap<IOFSwitch, HashMap<Integer, ArrayList<FlowQueue>>> switchQueueMap,
			Flow flowToRelease) {
		// TODO Auto-generated method stub
		Collection<OFPortDesc> ports = sw.getPorts();
		for(OFPortDesc portDesc : ports){
			
			int portNum = portDesc.getPortNo().getPortNumber();
			HashMap<Integer, ArrayList<FlowQueue>> portNumQueueMap = switchQueueMap.get(sw);
			
			for(Integer portNumInMap : portNumQueueMap.keySet()){
				
				if(portNumInMap.intValue() == portNum){
					
					ArrayList<FlowQueue> queues = portNumQueueMap.get(portNumInMap);
					
					for(int queueIndex = 0; queueIndex < queues.size(); queueIndex++){
						
						FlowQueue queue = queues.get(queueIndex);
						if(queue.getFlowID() == flowToRelease.getID()){
							switchQueueMap.get(sw).get(portNumInMap).get(queueIndex).setUsed(false);
							switchQueueMap.get(sw).get(portNumInMap).get(queueIndex).setFlowID(-1);
						}
					}
				}
			}
		}
	}

}
