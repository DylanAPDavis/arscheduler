package net.floodlightcontroller.arscheduler;

public class FlowQueue{
	protected int portNum;
	protected long queueId;
	protected long bandwidth;
	protected boolean used;
	protected long flowID;
	
	public FlowQueue(int pNum, long qId, long bw){
		portNum = pNum;
		queueId = qId;
		bandwidth = bw;
		used = false;
		flowID = -1;
	}
	
	public int getPortNum() {
		return portNum;
	}

	public void setPortNum(int portNum) {
		this.portNum = portNum;
	}

	public long getQueueId() {
		return queueId;
	}

	public void setQueueId(long queueId) {
		this.queueId = queueId;
	}

	public long getBandwidth() {
		return bandwidth;
	}

	public void setBandwidth(long bandwidth) {
		this.bandwidth = bandwidth;
	}

	public boolean isUsed() {
		return used;
	}

	public void setUsed(boolean used) {
		this.used = used;
	}

	public long getFlowID() {
		return flowID;
	}

	public void setFlowID(long flowID) {
		this.flowID = flowID;
	}

}
