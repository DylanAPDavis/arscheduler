package net.floodlightcontroller.arscheduler;

public class FlowRouteTuple {
	private Flow theFlow;
	private Topology theShortestPathTopology;
	private boolean released;
	
	
	public FlowRouteTuple(Flow f, Topology t)
	{
		theFlow = f;
		theShortestPathTopology = t;
		setReleased(false);
	}
	
	public Flow getFlow()
	{
		return theFlow;
	}
	
	public Topology getShortestPathtopology()
	{
		return theShortestPathTopology;
	}

	public boolean isReleased() {
		return released;
	}

	public void setReleased(boolean released) {
		this.released = released;
	}
	
	
}
