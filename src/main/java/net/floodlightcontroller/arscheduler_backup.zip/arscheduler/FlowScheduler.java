package net.floodlightcontroller.arscheduler;

import java.util.HashMap;

public class FlowScheduler {
	ResourceManager theResourceManager;
	BandwidthPruner bwPruner;
	ShortestPathEngine spEngine;
	
	public FlowScheduler(ResourceManager rm)
	{
		theResourceManager = rm;
	}
	
	public Flow scheduleNewFlow(Flow flow)
	{
		Topology prunedTopology;
		Topology shortestPath;
		
		bwPruner = new BandwidthPruner(theResourceManager.getTopology());
		prunedTopology = bwPruner.pruneTopology(flow.getBandwidth());
		
		if(prunedTopology.isEmpty())
			return null;
		
		//System.out.println("PRUNED TOPOLOGY:");
		//prunedTopology.dumpTopology();
						
		spEngine = new ShortestPathEngine(prunedTopology);
		shortestPath = spEngine.calculateSP(flow);
		
		shortestPath.dumpTopology();
				
		if(shortestPath.isEmpty())
		{
			System.out.println("No Feasible Path");
			return null;
		}
		
				
		for(FlowLink l : shortestPath.getLinks())
		{
			theResourceManager.decreaseLinkBandwidth(l, flow.getBandwidth());
		}
				
		/*for(Node n : shortestPath.getNodes())
		{
			if(n.nodeIsSwitch())
			{
				FlowTableRule newRule = new FlowTableRule(flow, (Switch)n);
				theResourceManager.getFlowTable().addRuleToFlowTable(newRule);
			}
		}*/
		
		theResourceManager.addFlowToRM(flow, shortestPath);
				
		flow.schedulingSuccess(true);
		return flow;
	}
	
	public boolean releaseFinishedFlow(Flow flow)
	{
		FlowRouteTuple flowRouteInfo = theResourceManager.getFlowFromRM(flow);
		
		if(flowRouteInfo == null)
			return false;
		
		assert(flow.getSuccess() == true);
		
		//Need to somehow get flow's path - links.
		Topology flowRoute = flowRouteInfo.getShortestPathtopology();
		
		for(FlowLink l : flowRoute.getLinks())
		{
			theResourceManager.increaseLinkBandwidth(l, flow.getBandwidth());
		}			
		
		theResourceManager.removeFlowFromRM(flow);
		
		return true;
	}
}
