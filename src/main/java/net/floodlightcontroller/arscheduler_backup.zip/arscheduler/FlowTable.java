package net.floodlightcontroller.arscheduler;

import java.util.ArrayList;

public class FlowTable 
{
	private ArrayList<FlowRouteTuple> allFlowRoutes;
	
	public FlowTable()
	{
		allFlowRoutes = new ArrayList<FlowRouteTuple>();
	}
	
	public void addFlowRouteTupleToFlowTable(FlowRouteTuple theRule)
	{
		allFlowRoutes.add(theRule);
	}
	
	
	public void removeAllFlowRouteTuples()
	{
		allFlowRoutes.clear();
	}
	
	public FlowRouteTuple findApplicableFlowRouteTuple(Flow theFlow)
	{
		
		
		for(FlowRouteTuple oneFlowRouteTuple : allFlowRoutes)
		{
			if(oneFlowRouteTuple.getFlow().equals(theFlow))
			{
				return oneFlowRouteTuple;
			}
		}
		
		return null;
	}
	
	public Flow matchFlow(long flowID)
	{
		for(FlowRouteTuple oneRouteTuple : allFlowRoutes)
		{
			Flow oneFlow = oneRouteTuple.getFlow();
			
			if((oneFlow.getID() == flowID))
			{
				return oneFlow;
			}
		}
		
		return null;
	}
	
	public boolean isEmpty()
	{
		return allFlowRoutes.isEmpty();
	}
	
	public ArrayList<FlowRouteTuple> getAllFlowRouteTuples()
	{
		return allFlowRoutes;
	}
	
}
