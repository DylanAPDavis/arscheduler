package net.floodlightcontroller.arscheduler;

public class Host extends Node 
{
	public Host(String name, int portNum) 
	{
		super(name, portNum);
	}

	@Override
	public void setNodeType() 
	{
		super.nodeType = "Host";		
	}

	@Override
	public boolean nodeIsSwitch() 
	{
		return false;
	}
}
