package net.floodlightcontroller.arscheduler;

import java.util.ArrayList;

import net.floodlightcontroller.core.module.IFloodlightService;

public interface IARSchedulerService extends IFloodlightService {
	public ArrayList<Node> initializeState();
	public Topology getTopology();
	public String handleNewFlow(Flow flow);
}
