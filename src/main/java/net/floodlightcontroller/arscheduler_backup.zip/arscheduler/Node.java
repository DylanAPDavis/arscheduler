package net.floodlightcontroller.arscheduler;

import java.util.ArrayList;

/** Input comes from SDN Controller **/
public abstract class Node 
{
	protected String nodeType;
	protected String nodeName;
	private ArrayList<Port> portList;
	private static int classNodeID = 0;
	private int nodeID;
	
	public Node(String name, int numPorts)
	{
		nodeName = name;
		portList = new ArrayList<Port>();
		
		for(int p = 1; p <= numPorts; p++)
		{
			Port onePort = new Port(p, "port-" + p);
			portList.add(onePort);
		}
		
		nodeID = ++classNodeID;
		
		setNodeType();
	}
	
	abstract public void setNodeType();
	
	abstract public boolean nodeIsSwitch();
	
	public String getNodeName()
	{
		return nodeName;
	}
	
	public String getNodeType()
	{
		return nodeType;
	}
	
	public ArrayList<Port> getPorts()
	{
		return this.portList;
	}
	
	public Port getPortByID(int ID){
		for(Port p : this.portList){
			if(p.getID() == ID){
				return p;
			}
		}
		return null;
	}
	
	public int getID()
	{
		return this.nodeID;
	}
	
	
	@Override
	public String toString()
	{
		return (nodeType + " " + nodeName);  
	}
	
	public boolean equals(Node anotherNode)
	{
		if(this.nodeType.equals(anotherNode.nodeType))
		{
			if(this.nodeName.equals(anotherNode.nodeName))
			{
				if(this.nodeID == anotherNode.getID())
				{
					return true;
				}
			}
		}
		
		return false;
	}
}
