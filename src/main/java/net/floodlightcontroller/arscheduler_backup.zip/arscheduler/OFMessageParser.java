package net.floodlightcontroller.arscheduler;

public class OFMessageParser 
{
	long flowID;  
	//String srcIP; 
	//String dstIP; 
		
	public void parseMessage(String theMessage)
	{
		String[] parsedMsg = theMessage.split(", ");
		
		for(String oneElement : parsedMsg)
		{
			if(oneElement.contains("cookie"))
			{
				String temp[] = oneElement.split("0x");
				flowID = Long.parseLong(temp[1]);
			}
			/*
			else if(oneElement.contains("ipv4_src"))
			{
				String temp[] = oneElement.split("=");
				srcIP = new String(temp[1]);
			}
			else if(oneElement.contains("ipv4_dst"))
			{
				String temp[] = oneElement.split("=");
				dstIP = new String(temp[1].substring(0, temp[1].length()-2));
				
			}
			*/
		}
	}	
}

