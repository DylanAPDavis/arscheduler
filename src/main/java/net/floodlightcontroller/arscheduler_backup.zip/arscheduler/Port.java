package net.floodlightcontroller.arscheduler;

/** Input comes from SDN Controller **/
public class Port 
{
	private int portID;
	private String portName;
	
	public Port(int num, String name)
	{
		portID = num;
		portName = name;
	}
	
	public int getID()
	{
		return portID;
	}
	
	public String getName()
	{
		return portName;
	}
	
}
