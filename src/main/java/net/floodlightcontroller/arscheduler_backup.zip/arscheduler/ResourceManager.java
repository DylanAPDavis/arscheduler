package net.floodlightcontroller.arscheduler;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.projectfloodlight.openflow.protocol.OFPortDesc;
import org.projectfloodlight.openflow.types.DatapathId;
import org.projectfloodlight.openflow.types.OFPort;

import net.floodlightcontroller.core.IOFSwitch;
import net.floodlightcontroller.devicemanager.IDevice;
import net.floodlightcontroller.devicemanager.SwitchPort;
import net.floodlightcontroller.routing.Link;

public class ResourceManager 
{
	private ArrayList<FlowLink> linkStatus = new ArrayList<FlowLink>();
	private FlowTable flowTable = new FlowTable();
	
	Topology netTopology;
	
	public void intializeState(Topology newTopology){
		netTopology = newTopology;
		linkStatus = netTopology.getLinks();
		flowTable.removeAllFlowRouteTuples();
	}
	
	public long getLinkBandwidthAvailable(FlowLink link)
	{
		assert !linkStatus.isEmpty();
		assert(link != null);
		assert(linkStatus.contains(link));
		
		return linkStatus.get(linkStatus.indexOf(link)).getBandwidthAvailabile();
	}
	
	// Returns TRUE if B/W reserved, FALSE if not enough B/W.
	public boolean decreaseLinkBandwidth(FlowLink link, long bwToReserve)
	{
		assert !linkStatus.isEmpty();
		assert(link != null);
		assert(linkStatus.contains(link));
						
		return linkStatus.get(linkStatus.indexOf(link)).decreaseBandwidthAvailable(bwToReserve);
	}
	
	// Returns TRUE if B/W freed, FALSE if it leads to B/W greater than capacity
	public boolean increaseLinkBandwidth(FlowLink link, long bwToFree)
	{
		assert !linkStatus.isEmpty();
		assert(link != null);
		assert(linkStatus.contains(link));
		
		return linkStatus.get(linkStatus.indexOf(link)).increaseBandwidthAvailable(bwToFree);
	}
	
	public FlowTable getFlowTable()
	{
		return flowTable;
	}
	
	public void addFlowToRM(Flow flow, Topology topo)
	{
		FlowRouteTuple frTuple = new FlowRouteTuple(flow, topo);
		flowTable.addFlowRouteTupleToFlowTable(frTuple);
		//allFlows.add(frTuple);
	}
	
	public void removeFlowFromRM(Flow flowToRemove)
	{
		for(FlowRouteTuple frTuple : flowTable.getAllFlowRouteTuples())
		{
			Flow oneFlow = frTuple.getFlow();
			
			if(oneFlow.equals(flowToRemove) && !frTuple.isReleased())
			{
				frTuple.setReleased(true);
				System.out.println("Flow " + oneFlow.getID() + " Released");
				return;
			}
		}
	}
	
	public FlowRouteTuple getFlowFromRM(Flow flow)
	{
		for(FlowRouteTuple frTuple : flowTable.getAllFlowRouteTuples())
		{
			if(frTuple.getFlow().equals(flow))
			{
				return frTuple;
			}
		}
		
		return null;	
	}
	
		
	public Topology getTopology()
	{
		return netTopology;
	}
	
	

}
