package net.floodlightcontroller.arscheduler;

import java.util.Calendar;
import java.util.Date;

public class SchedulingThread implements Runnable 
{
	static int tID = 0;
	int threadID;
	
	Calendar scheduledCal;
	Thread theSchedulingThread;
	ARScheduler schedulingCoordinator;
	Flow flowToSchedule;

	// Constructor
	public SchedulingThread(ARScheduler coordinator, Flow flow, int hour, int minute, int second)
	{
		threadID = ++tID;
		
		schedulingCoordinator = coordinator;
		flowToSchedule = flow;
		
		theSchedulingThread = new Thread(this);
		
		Calendar initialCal = Calendar.getInstance();
		
		Date scheduledDate = initialCal.getTime();
		scheduledDate.setHours(hour);
		scheduledDate.setMinutes(minute);
		scheduledDate.setSeconds(second);
		
		scheduledCal = Calendar.getInstance();
		scheduledCal.setTime(scheduledDate);
	
		theSchedulingThread.start();	// Start background thread
	}
	
	@Override
	public void run() 
	{
		System.out.println("Initializing new Scheduling Thread for Flow " + flowToSchedule.getID() + ".");
		System.out.println("Flow " + flowToSchedule.getID() + " will be established at time " +  scheduledCal.get(Calendar.HOUR_OF_DAY) + ":" + scheduledCal.get(Calendar.MINUTE) + ":" + scheduledCal.get(Calendar.SECOND) + ".");
		
		Calendar currentCal = Calendar.getInstance();
								
		while(currentCal.before(scheduledCal))
		{
			currentCal = Calendar.getInstance();
		}
		
		System.out.println("Current Time = " + currentCal.get(Calendar.HOUR_OF_DAY) + ":" + currentCal.get(Calendar.MINUTE) + ":" + currentCal.get(Calendar.SECOND));
		System.out.println("SCHEDULING Flow " + flowToSchedule.getID() + "!");
		
		schedulingCoordinator.flowProvisioner.provisionFlowPath(schedulingCoordinator.theRM.getFlowFromRM(flowToSchedule), schedulingCoordinator.switchMap, schedulingCoordinator.switchQueueMap);
		
		System.out.println("Flow " + flowToSchedule.getID() + " ACTIVE!");
	}
}
