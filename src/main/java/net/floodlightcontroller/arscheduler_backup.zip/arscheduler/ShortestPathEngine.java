package net.floodlightcontroller.arscheduler;

import java.util.ArrayList;

public class ShortestPathEngine 
{
	Topology workingTopology;
	
	public ShortestPathEngine(Topology topo)
	{
		workingTopology = topo;
	}
	
	public Topology calculateSP(Flow flow)
	{
		Topology spTopology;
		WeightedGraph weightedGraph = new WeightedGraph(workingTopology); 		// Convert Topology to adjacency matrix.
		int[] prevNodes = dijkstrasAlgorithm(weightedGraph, flow.getSource());	// Dijkstra.
		ArrayList<Node> shortestPath = reportSP(weightedGraph, prevNodes, flow.getSource(), flow.getDest());
		ArrayList<FlowLink> linksOnPath;
				
		linksOnPath = this.getLinksOnSP(shortestPath);
		
		spTopology = new Topology(shortestPath, linksOnPath);
				
		return spTopology;		
	}

	//Dijkstra's algorithm to find shortest path from s to all other nodes
	public int[] dijkstrasAlgorithm(WeightedGraph G, Node srcNode) 
	{
		int s = G.indexOf(srcNode);
		int[] dist = new int[G.size()];  // shortest known distance from "s"
		int[] pred = new int[G.size()];  // preceeding node in path
		boolean[] visited = new boolean[G.size()]; // all false initially

		for(int i = 0; i < dist.length; i++) 
		{
			dist[i] = Integer.MAX_VALUE;
		}
		dist[s] = 0;

		for(int i = 0; i < dist.length; i++) 
		{
			final int next = minVertex(dist, visited);
			
			visited[next] = true;
	  
			// The shortest path to next is dist[next] and via pred[next].

			final int[] n = G.neighbors(next);

			for(int j = 0; j < n.length; j++) 
			{
				final int v = n[j];
				final int d = dist[next] + G.getWeight(next,v);
				if(dist[v] > d) 
				{
					dist[v] = d;
					pred[v] = next;
				}
			}
		}
		pred[s] = s;
		
		return pred;  // (ignore pred[s]==0!)
	}
	  
	private int minVertex(int[] dist, boolean[] v) 
	{
		int x = Integer.MAX_VALUE;
		int y = -1;   // graph not connected, or no unvisited vertices
		for(int i = 0; i < dist.length; i++) 
		{
			if (!v[i] && (dist[i] < x)) 
			{
				y=i; 
				x=dist[i];
			}
		}

		return y;
	}

	
	public ArrayList<Node> reportSP(WeightedGraph G, int[] pred, Node src, Node dst) 
	{
		int s = G.indexOf(src);
		int d = G.indexOf(dst);
		
		ArrayList<Node> path = new ArrayList<Node>();
		int x = d;
		
		while(x != s) 
		{
			path.add(0, G.getNodeValueAtIndex(x));
			x = pred[x];
		}
		
		path.add(0, G.getNodeValueAtIndex(s));
		
		return path;
	}
	
	private ArrayList<FlowLink> getLinksOnSP(ArrayList<Node> spNodes)
	{
		ArrayList<FlowLink> linksToInclude = new ArrayList<FlowLink>();
		ArrayList<FlowLink> unprunedLinks = workingTopology.getLinks(); 
		for(int i = 0; i < spNodes.size() - 1; i++)
		{
			int j = i + 1;
			
			Node nodeI = spNodes.get(i);
			Node nodeJ = spNodes.get(j);
			
			for(FlowLink link : unprunedLinks)
			{
				if(link.getSrcNode().equals(nodeI) && link.getDstNode().equals(nodeJ))
				{
					linksToInclude.add(link);
				}
				if(link.getDstNode().equals(nodeI) && link.getSrcNode().equals(nodeJ))
				{
					linksToInclude.add(link);
				}
			}
		}
		
		return linksToInclude;
	}
	
}
