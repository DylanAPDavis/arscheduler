package net.floodlightcontroller.arscheduler;

public class Switch extends Node 
{

	public Switch(String name, int portNum) 
	{
		super(name, portNum);
	}

	@Override
	public void setNodeType() 
	{
		super.nodeType = "Switch";
	}

	@Override
	public boolean nodeIsSwitch() 
	{
		return true;
	}
}

