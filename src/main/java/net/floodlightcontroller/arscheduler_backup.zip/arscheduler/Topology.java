package net.floodlightcontroller.arscheduler;

import java.util.ArrayList;

/** Input comes from SDN Controller **/
public class Topology 
{
	private ArrayList<Node> topologyNodes = new ArrayList<Node>();
	private ArrayList<FlowLink> topologyLinks = new ArrayList<FlowLink>();
	
	public Topology(ArrayList<Node> topoNodes, ArrayList<FlowLink> topoLinks)
	{
		this.topologyNodes = topoNodes;
		this.topologyLinks = topoLinks;
	}
		
	public void dumpTopology()
	{
		System.out.println("NODES:");
		for(Node n : topologyNodes)
		{
			System.out.println(n);
		}
		
		System.out.println();
		
		System.out.println("LINKS:");
		for(FlowLink l : topologyLinks)
		{
			System.out.println(l);
		}
	}
	
	public ArrayList<String> dumpTopologyString(){
		ArrayList<String> topoOutput = new ArrayList<String>();
		topoOutput.add("Nodes:");
		for(Node n : topologyNodes)
		{
			topoOutput.add(n.toString());
		}
		
		
		topoOutput.add("LINKS:");
		for(FlowLink l : topologyLinks)
		{
			topoOutput.add(l.toString());
		}
		return topoOutput;
	}
	
	public ArrayList<Node> getNodes()
	{
		return this.topologyNodes;
	}
	
	public ArrayList<FlowLink> getLinks()
	{
		return this.topologyLinks;
	}
	
	
	public boolean isEmpty()
	{
		return topologyLinks.isEmpty();
	}

	public Node getNodeByName(String nodeName){
		for(Node n : topologyNodes){
			if(n.getNodeName().equals(nodeName)){
				return n;
			}
		}
		return null;
	}
	@Override
	public String toString() {
		return "Topology [topologyNodes=" + topologyNodes + ", topologyLinks="
				+ topologyLinks + "]";
	}
}

