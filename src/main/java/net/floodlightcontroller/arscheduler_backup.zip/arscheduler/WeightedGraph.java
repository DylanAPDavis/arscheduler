package net.floodlightcontroller.arscheduler;

import java.util.ArrayList;
import java.util.Arrays;

//Representation of Topology as Adjacency Matrix
public class WeightedGraph 
{
	private int[][] adjacencyMatrix;
	private ArrayList<ArrayList<Node>> nodeMatrix = new ArrayList<ArrayList<Node>>(); 
	
	public WeightedGraph(Topology topo)
	{	
		adjacencyMatrix = new int[topo.getNodes().size()][topo.getNodes().size()];
		
		// Initialize all weights to "infinity"
		for(int x = 0; x < adjacencyMatrix.length; x++)
		{
			for(int y = 0; y < adjacencyMatrix[x].length; y++)
			{
				adjacencyMatrix[x][y] = 9999;
			}
		}
		
		for(Node m : topo.getNodes())
		{
			ArrayList<Node> oneDimension = new ArrayList<Node>();
			oneDimension.add(m);
			for(Node n : topo.getNodes())
			{
				oneDimension.add(n);
			}
			
			nodeMatrix.add(oneDimension);
		}
						
		for(FlowLink l : topo.getLinks())
		{
			Node srcNode = l.getSrcNode();
			Node dstNode = l.getDstNode();
			
			for(int n = 0; n < nodeMatrix.size(); n++)
			{
				if(srcNode.equals(nodeMatrix.get(n).get(0)))
				{
					int index = nodeMatrix.get(n).indexOf(dstNode) - 1;	// Must map from nodeMatrix to adjacencyMatrix
					
					adjacencyMatrix[n][index] = 1;
																				
					break;
				}
			}				
		}
	}
	
	public int getWeight(int src, int dst)
	{
		return adjacencyMatrix[src][dst];
	}
	
	public int size()
	{
		return adjacencyMatrix.length;
	}
	
	public int[] neighbors(int node)
	{
		int[] adjacentIndeces = new int[adjacencyMatrix.length];
		int[] neighbors;
		int i = 0;
		
		for(int n = 0; n < adjacencyMatrix[node].length; n++)
		{
			if(node == n)
				continue;
				
			if(adjacencyMatrix[node][n] > 0)
			{
				adjacentIndeces[i] = n;
				i++;
			}
		}
		
		neighbors = new int[i];
		
		for(int x = 0; x < i; x++)
		{
			neighbors[x] = adjacentIndeces[x];
		}
				
		return neighbors;
	}
	
	public int indexOf(Node node)
	{
		int i = 0;
		for(ArrayList<Node> oneDimension : nodeMatrix)
		{
			if(oneDimension.get(0).getNodeName().equals(node.getNodeName()))
			{
				return i;
			}
			
			i++;
		}
		
		return -1;
	}
	
	public Node getNodeValueAtIndex(int index)
	{
		return nodeMatrix.get(index).get(0);
	}

	@Override
	public String toString() {
		ArrayList<ArrayList<String>> formattedAdjacencyMatrix = new ArrayList<ArrayList<String>>();
		for(int x = 0; x < adjacencyMatrix.length; x++)
		{
			ArrayList<String> formattedAdjacencyRow = new ArrayList<String>();
			for(int y = 0; y < adjacencyMatrix[x].length; y++)
			{
				formattedAdjacencyRow.add(String.valueOf(adjacencyMatrix[x][y]));
			}
			formattedAdjacencyMatrix.add(formattedAdjacencyRow);
		}
		return "WeightedGraph [adjacencyMatrix="
				+ formattedAdjacencyMatrix.toString() + ", nodeMatrix="
				+ nodeMatrix + "]";
	}
}

